import React, { Component } from 'react';
import Logo from "../../Shared/icons8-twitter-144.png";
import "./Users.css";
import { useState,useEffect } from 'react';
import  { useNavigate } from 'react-router-dom';

function Users() {
    const [response, setResponse] = useState([]);
    const redirect = useNavigate();
    useEffect(() => {
        var username = null;
        var token = null;
        if (localStorage.getItem("username")) {
            username = localStorage.getItem("username");
            token = localStorage.getItem("Token")
        }
        fetch("http://localhost:8081/api/v1.0/tweets/users/all", {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'same-origin',
                'Authorization': 'Bearer ' + token
            },
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                alert(data.errorMsg);
                return;
            }
            setResponse(data);
        }).catch(error => {
            localStorage.removeItem("username");
            localStorage.removeItem("Token");
            redirect('/tweetapp/login');
        })
    }, []);

    const loadData = () => {
        let result = [];
        response.forEach(element => {
            result.push(
                <main class="mb-2">
                    <img class="photo" src={Logo} alt="" />
                    <div class="buttons">
                        <a class="following-btn btn btn-primary" href={"/tweetapp/tweets?userId="+element.loginId}>Tweets</a>
                    </div>
                    <h2 class="name">{element.firstName+" " + element.lastName}</h2>
                    <h3 class="handle">{element.loginId}</h3>
                    <p class="profile-detail">
                        <span><span class="bolder-weight">Email : </span>{element.email}</span>
                    </p>
                </main>
            )
        })
        return result;
    }
    return (
        <div class="home-container">
            <header>
                <img src={Logo} />
                <h1 class="username-home"> Tweet App </h1>
            </header>
            <div class="main">
                <div id="tweets">
                    <h5>All Users</h5>
                    <div id="list-tweets">
                        {loadData()}
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Users;