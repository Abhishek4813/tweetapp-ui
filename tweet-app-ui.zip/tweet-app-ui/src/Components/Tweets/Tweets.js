import React, {Component} from 'react';
import Logo from "../../Shared/icons8-twitter-144.png";
import Tweet from '../TweetTemplate/Tweet';

class Tweets extends Component{
    render(){
        return(
            <div class="home-container">
            <header>
                <img src={Logo}/>
            </header>
            <div class="main">
                <div id="tweets">
                    <h5>All Tweets</h5>
                    <div id="list-tweets">
                        <Tweet/>
                        <Tweet/>
                    </div>
                </div>
            </div>
        </div>
        )
    }
}
export default Tweets;