import React, { Component } from 'react';
import { useState } from 'react';
import "./Register.css"

function Register() {
    const [inputs, setInputs] = useState({});
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values, [name]: value}))
        if(event.target.value==""){
            event.target.classList.add("is-invalid");
        }
        else{
            event.target.classList.remove("is-invalid");

        }

      }
      const handleSubmit = (event) => {
        event.preventDefault();
        console.log(inputs);
      }
        return (
            <div class="container">
                <div id="registrationForm" class="card mr-auto ml-auto mt-4 p-4 hidden">
                    <h2 class="text-secondary text-center">Register</h2>
                    <form class="p-4 form" onSubmit={handleSubmit}>
                        <div class="form-group">
                            <label for="firstname">
                                First name
                            </label>
                            <input type="text" name="firstName" class="form-control" value={inputs.firstName || ""} onChange={handleChange}  required/>
                        </div>
                        <div class="form-group">
                            <label for="lastname">
                                Last name
                            </label>
                            <input type="text" name="lastName" class="form-control" value={inputs.lastName || ""} onChange={handleChange} required/>
                        </div>
                        <div class="form-group">
                            <label for="username">
                                Username
                            </label>
                            <input type="text" name="loginId" class="form-control" value={inputs.loginId || ""} onChange={handleChange} required/>
                        </div>
                        <div class="form-group">
                            <label for="email">
                                Email
                            </label>
                            <input type="email" name="email" class="form-control" value={inputs.email || ""} onChange={handleChange} required/>
                        </div>
                        <div class="form-group">
                            <label for="Phone">
                                Phone Number
                            </label>
                            <input type="ttl" name="contactNumber" class="form-control" value={inputs.contactNumber || ""} onChange={handleChange} required/>
                        </div>
                        <div class="form-group">
                            <label for="password">
                                Password
                            </label>
                            <input type="text" name="password" class="form-control" value={inputs.password || ""}  onChange={handleChange} required/>
                        </div>
                        <div class="form-group">
                            <label for="confirmPassword">
                                Confirm Password
                            </label>
                            <input type="text" name="confirmPassword" class="form-control" value={inputs.confirmPassword ||""} onChange={handleChange} required/>
                        </div>
                        <br />
                        <input type="submit" value="Register" class="btn btn-primary btn-block" />
                    </form>
                    <br />
                    <p class="text-right">Already have an account? <a href="/tweetapp/login">Login here.</a></p>
                </div>
            </div>
        )
}
export default Register;