import React from 'react';
import Logo from "../../Shared/icons8-twitter-144.png";
import Tweet from '../TweetTemplate/Tweet';
import { useState,useEffect } from 'react';
import  { useNavigate,useLocation } from 'react-router-dom';

function Tweets(){
    const [response,setResponse]=useState([]);
    const redirect = useNavigate();
    const search = useLocation().search;
    useEffect(()=>{
        var username="all";
        var token=null;
        const name = new URLSearchParams(search).get('userId');
        if(null != name){
            username=name;
            document.getElementById("heading-text").innerHTML="Tweets by "+name;
        }
        if(localStorage.getItem("username")){
            token=localStorage.getItem("Token")
        }
        fetch("http://localhost:8081/api/v1.0/tweets/"+username, {
            method: 'get',         
            headers: {
               'Content-Type': 'application/json',
               'credentials': 'same-origin',
               'Authorization': 'Bearer '+token
            },
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                alert(data.errorMsg);
                return;
            }
            setResponse(data); 
        }).catch(error => {
            localStorage.removeItem("username");
            localStorage.removeItem("Token");
            redirect('/tweetapp/login');
        })
    },[]);
    const loadData =()=>{
        let result=[];
        response.forEach(element => {
            result.push(<Tweet tweetData={element}/>);
        });
        return result;
    }
        return(
            <div class="home-container">
            <header>
                <img src={Logo}/>
            </header>
            <div class="main">
                <div id="tweets">
                    <h5 id="heading-text">All Tweets</h5>
                    <div id="list-tweets">
                        {loadData()}
                    </div>
                </div>
            </div>
        </div>
        )
}
export default Tweets;