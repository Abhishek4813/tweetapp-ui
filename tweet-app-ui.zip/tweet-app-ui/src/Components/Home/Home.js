import React from 'react';
import "./Home.css";
import { useState,useEffect } from 'react';
import { Alert } from 'reactstrap';
import  { useNavigate } from 'react-router-dom';
import Logo from "../../Shared/icons8-twitter-144.png";
import Tweet from '../TweetTemplate/Tweet';

function Home() {
    const [inputs, setInputs] = useState({});
    const [response,setResponse]=useState([]);
    const [username, setUsername] = useState("");
    const [show, setShow] = useState(false);
    const [errorMsg, setError] =useState('');
    const redirect = useNavigate();
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({ ...values, [name]: value }))
        if (event.target.value == "") {
            event.target.classList.add("is-invalid");
        }
        else {
            event.target.classList.remove("is-invalid");

        }

    }
    useEffect(()=>{
        var username=null;
        var token=null;
        if(localStorage.getItem("username")){
            username=localStorage.getItem("username");
            token=localStorage.getItem("Token")
            setUsername(username);
        }
        fetch("http://localhost:8081/api/v1.0/tweets/"+username, {
            method: 'get',         
            headers: {
               'Content-Type': 'application/json',
               'credentials': 'same-origin',
               'Authorization': 'Bearer '+token
            },
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                setError(data.errorMsg);
                setShow(true);
                return;
            }
            setResponse(data); 
        }).catch(error => {
            localStorage.removeItem("username");
            localStorage.removeItem("Token");
            redirect('/tweetapp/login');
        })
    },[]);

    const loadData =()=>{
        let result=[];
        response.forEach(element => {
            result.push(<Tweet tweetData={element}/>);
        });
        return result;
    }
    const onDismiss = () => setShow(false);
    const handleSubmit = (event) => {
        event.preventDefault();
        var username=null;
        var token=null;
        if(localStorage.getItem("username")){
            username=localStorage.getItem("username");
            token=localStorage.getItem("Token")
        }
        fetch("http://localhost:8081/api/v1.0/tweets/"+username+"/add", {
            method: 'post',
            body: JSON.stringify(inputs),         
            headers: {
               'Content-Type': 'application/json',
               'credentials': 'same-origin',
               'Authorization': 'Bearer '+token
            },
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                setError(data.errorMsg);
                setShow(true);
                return;
            }
            redirect(0);  
        }).catch(error => {
            localStorage.removeItem("username");
            localStorage.removeItem("Token");
            redirect('/tweetapp/login');
        })
    }
    return (
        <div class="home-container">
            <Alert color="danger" isOpen={show} toggle={onDismiss}>
                <strong>Error ! </strong> {errorMsg}
            </Alert>
            <header>
                <img src={Logo} />
                <h1 class="username-home">{username}</h1>
            </header>
            <div class="main">
                <form id="form" onSubmit={handleSubmit}>
                    <p>Tweet</p>
                    <textarea id="tweet" class="form-control" rows="3" placeholder="Enter Here...." name="description" value={inputs.description || ""} onChange={handleChange} required></textarea>
                    <textarea id="tweet" class="form-control mt-2 tags" placeholder="Add Tags..." rows="3" name="tags" value={inputs.tags || ""} onChange={handleChange} required></textarea>
                    <button type="submit" class="btn btn-primary mt-3">Tweet</button>
                </form>
                <div id="tweets">
                    <h5>My Tweets</h5>
                    <div id="list-tweets">
                       {loadData()}
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Home