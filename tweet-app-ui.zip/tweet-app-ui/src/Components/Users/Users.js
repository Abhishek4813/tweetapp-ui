import React, { Component } from 'react';
import Logo from "../../Shared/icons8-twitter-144.png";
import "./Users.css";

class Users extends Component {
    render() {
        return (
            <div class="home-container">
                <header>
                    <img src={Logo} />
                    <h1 class="username-home"> Abhishek kumar </h1>
                </header>
                <div class="main">
                    <form id="form">
                        <p>Tweet</p>
                        <textarea id="tweet" class="form-control" rows="3"></textarea>
                        <button type="submit" class="btn btn-primary mt-3">Tweet</button>
                    </form>
                    <div id="tweets">
                        <h5>All Users</h5>
                        <div id="list-tweets">
                            <main>
                                <img class="photo" src={Logo} alt="" />
                                <div class="buttons">
                                    <a class="following-btn btn btn-primary" href="/tweetapp/tweets">Tweets</a>
                                </div>
                                <h2 class="name">Abhishek kumar</h2>
                                <h3 class="handle">@abhi29</h3>
                                <p class="profile-detail">
                                    <span><span class="bolder-weight">Email : </span>abhi@gmail.com</span>
                                    <span><span class="bolder-weight">Total Tweets : </span>200</span>
                                    <span><span class="bolder-weight">Total Likes:</span> 400</span>
                                </p>
                            </main>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default Users;