import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Navbar from './Components/Navigation/Navbar';
import reportWebVitals from './reportWebVitals';
import "bootstrap/dist/css/bootstrap.min.css";
import { browserHistory, Route, Router } from 'react-router';
import Home from './Components/Home/Home';
import Users from './Components/Users/Users';
import Tweets from './Components/Tweets/Tweets';
import Register from './Components/Register/Register';
import Login from './Components/Login/Login';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Router  history={browserHistory}>
    <Route path={"/"} component={App} />
      <Route path={"/tweetapp"} component={Navbar}>
        <Router path="/tweetapp/home" component={Home} />
        <Router path="/tweetapp/register" component={Register} />
        <Router path="/tweetapp/users" component={Users} />
        <Router path="/tweetapp/tweets" component={Tweets} />
        <Router path="/tweetapp/login" component={Login} />
      </Route>
  </Router>
); 

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
