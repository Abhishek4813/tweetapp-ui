import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
import Login from './Components/Login/Login';
import Navbar from './Components/Navigation/Navbar';

class App extends Component {
  render(){
  return (
    <div className="App">
      <Navbar />
      <Login />
    </div>
  );
}
}

export default App;
