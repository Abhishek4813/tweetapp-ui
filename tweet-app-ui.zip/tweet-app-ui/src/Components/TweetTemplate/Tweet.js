import React, { useState, useEffect } from 'react';
import { Accordion, AccordionBody, AccordionHeader, AccordionItem, } from 'reactstrap';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import "./Tweet.css";
import Logo from "../../Shared/icons8-twitter-144.png";

function Tweet(props) {
    const [open, setOpen] = useState('1');
    const [tweet, setTweet] = useState(props.tweetData)
    const [inputs, setInputs] = useState({});
    const [updateInputs, setUpdate] = useState({});
    const [modal, setModal] = useState(false);
    const [action, setAction] = useState(false);
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({ ...values, [name]: value }))
        if (event.target.value == "") {
            event.target.classList.add("is-invalid");
        }
        else {
            event.target.classList.remove("is-invalid");

        }

    }
    useEffect(() => {
        var user = null
        if (localStorage.getItem("username"))
            user = localStorage.getItem("username");
        if (user == tweet.username) {
            setAction(true);
        }

    }, []);
    const handleUpdateChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setUpdate(values => ({ ...values, [name]: value }))
        if (event.target.value == "") {
            event.target.classList.add("is-invalid");
        }
        else {
            event.target.classList.remove("is-invalid");

        }

    }
    const editButton = () => {
        return (
            <div class="edit-action-button" id="edit-tweet-btn">
                <button class="btn btn-sm edit-action" onClick={toggleModal}>Edit</button>
            </div>
        )
        }
        const deleteButton = () => {
            return (
                <div class="delete-action-button" id="delete-tweet-btn">
                    <button class=" btn btn-sm delete-action" onClick={deletePost}>Delete</button>
                </div>
            )
    }

    const likePost = () => {
        var username = null;
        var token = null;
        var tweetId = tweet.id;
        if (localStorage.getItem("username")) {
            username = localStorage.getItem("username");
            token = localStorage.getItem("Token")
        }
        fetch("http://localhost:8081/api/v1.0/tweets/" + username + "/like/" + tweetId, {
            method: 'put',
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'same-origin',
                'Authorization': 'Bearer ' + token
            }
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                alert(data.errorMsg);
                return;
            }
            setTweet(data);
        }).catch(error => {
            alert(error);
        })
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        var username = null;
        var token = null;
        var tweetId = tweet.id;
        if (localStorage.getItem("username")) {
            username = localStorage.getItem("username");
            token = localStorage.getItem("Token")
        }
        inputs.tags = "NA";
        fetch("http://localhost:8081/api/v1.0/tweets/" + username + "/reply/" + tweetId, {
            method: 'post',
            body: JSON.stringify(inputs),
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'same-origin',
                'Authorization': 'Bearer ' + token
            }
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                alert(data.errorMsg);
                return;
            }
            setTweet(data);
        }).catch(error => {
            alert(error);
        })
    }

    const handleUpdate = (event) => {
        event.preventDefault();
        var username = null;
        var token = null;
        var tweetId = tweet.id;
        console.log(updateInputs);
        if (localStorage.getItem("username")) {
            username = localStorage.getItem("username");
            token = localStorage.getItem("Token")
        }
        fetch("http://localhost:8081/api/v1.0/tweets/" + username + "/update/" + tweetId, {
            method: 'put',
            body: JSON.stringify(updateInputs),
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'same-origin',
                'Authorization': 'Bearer ' + token
            }
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                alert(data.errorMsg);
                return;
            }
            setTweet(data);
        }).catch(error => {
            alert(error);
        })
    }

    const toggle = (id) => {
        if (open === id) {
            setOpen();
        } else {
            setOpen(id);
        }
    };
    const deletePost = () => {
        var username = null;
        var token = null;
        var tweetId = tweet.id;
        if (localStorage.getItem("username")) {
            username = localStorage.getItem("username");
            token = localStorage.getItem("Token")
        }
        fetch("http://localhost:8081/api/v1.0/tweets/" + username + "/delete/" + tweetId, {
            method: 'delete',
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'same-origin',
                'Authorization': 'Bearer ' + token
            }
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                alert(data.errorMsg);
                return;
            }
            //redirect('/tweetapp/login');  
        }).catch(error => {
            alert(error);
        })
    }
    const toggleModal = () => {
        setModal(!modal);
        if (!modal)
            setUpdate(tweet);
        else
            setUpdate(updateInputs);
    }
    const loadComment = () => {
        let data = [];
        tweet.reply.forEach(element => {
            data.push(
                <div class="comment-replies mt-4 bg-light p-3 ml-3 rounded">
                    <div class="tweet-header">
                        <div class="tweet-header-info-comment">
                            <span class="comment-detail">{element.userId}</span><span>. {foramtTime(element.time)}</span>
                            <p class="comment-text">{element.description}</p>
                        </div>
                    </div>
                </div>
            )
        });
        return data;
    }
    const foramtTime = (time) => {
        return new Date(time).toDateString();
    }
    return (
        <div class="tweet-container">
            <Accordion class="tweet-wrap" open={open} toggle={toggle}>
                <AccordionItem>
                    <div class="tweet-header">
                        <img src={Logo} alt="" class="avator" />
                        <div class="tweet-header-info">
                            {tweet.username} <span>@{tweet.username} </span><span>. {foramtTime(tweet.time)}
                            </span>
                            <p class="desc-element">{tweet.description}</p>
                            <p class="tag-element">{tweet.tags}</p>
                        </div>
                    </div>
                    <div class="tweet-info-counts">
                        <AccordionHeader class="comments" targetId="1">
                            <svg class="feather feather-message-circle sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                            <div class="comment-count">{tweet.reply.length}</div>
                        </AccordionHeader>
                        <div class="likes" onClick={likePost}>
                            <svg class="feather feather-heart sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                            <div class="likes-count">
                                {tweet.likes}
                            </div>
                        </div>
                        {action ? editButton() :null}
                        {action ? deleteButton() : null}
                    </div>
                    <AccordionBody accordionId="1">
                        {loadComment()}
                        <form class="input-group mb-3" onSubmit={handleSubmit}>
                            <input type="text" class="form-control" placeholder="Comment here..." aria-label="Recipient's username" aria-describedby="button-addon2" name="description" value={inputs.description || ""} onChange={handleChange} required />
                            <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Reply</button>
                        </form>
                    </AccordionBody>
                </AccordionItem>
            </Accordion>
            <Modal isOpen={modal} toggle={toggleModal}>
                <ModalHeader toggle={toggleModal}>Update Tweet</ModalHeader>
                <form onSubmit={handleUpdate}>
                    <ModalBody>

                        <textarea id="tweet" class="form-control" rows="3" placeholder="Enter Here...." name="description" value={updateInputs.description || ""} onChange={handleUpdateChange} required></textarea>
                        <textarea id="tweet" class="form-control mt-2 tags" placeholder="Add Tags..." rows="3" name="tags" value={updateInputs.tags || ""} onChange={handleUpdateChange} required></textarea>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" type="submit" onClick={toggleModal}>Update Tweet</Button>{' '}
                        <Button color="secondary" type="reset" onClick={toggleModal}>Cancel</Button>
                    </ModalFooter>
                </form>
            </Modal>
        </div>
    )
}
export default Tweet;