import React, { Component } from 'react';
import "./Navbar.css";
class Navigationbar extends Component {
  loginText;
  constructor() {
    super();
    this.loginText = "Login/Signup";
  }
 handleLogin() {
    if (localStorage.getItem("Token")) {
      localStorage.removeItem("Token");
      localStorage.removeItem("username");
    }
  }

  render() {
    if (localStorage.getItem("Token")) {
      this.loginText = "Logout";
    }
    return (
      <div class="App">
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
          <div class="container-fluid">
            <a class="navbar-brand" href="/">TweetApp</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
              <ul class="navbar-nav me-auto">
                <li class="nav-item">
                  <a class="nav-link" href="/tweetapp/home">HOME</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/tweetapp/tweets">TWEETS</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/tweetapp/users">ALL USERS</a>
                </li>
              </ul>
              <form class="d-flex">
                <a class="btn btn-primary" id="loginbtn" type="button" onClick={this.handleLogin} href="/tweetapp/login">{this.loginText}</a>
              </form>
            </div>
          </div>
        </nav>
        <div>
        </div>
      </div>
    )
  }
}
export default Navigationbar;
