import React, { useState } from 'react';
import { Accordion, AccordionBody, AccordionHeader, AccordionItem, } from 'reactstrap';
import "./Tweet.css";
import Logo from "../../Shared/icons8-twitter-144.png";

function Tweet(props) {
    const [open, setOpen] = useState('1');
    const toggle = (id) => {
        if (open === id) {
            setOpen();
        } else {
            setOpen(id);
        }
    };
    return (
        <Accordion class="tweet-wrap" open={open} toggle={toggle}>
            <AccordionItem>
                <div class="tweet-header">
                    <img src={Logo} alt="" class="avator" />
                    <div class="tweet-header-info">
                        Steve Schoger <span>@Steve Schoger</span><span>. Jun 27
                        </span>
                        <p>🔥 If you're tired of using outline styles for secondary buttons, a soft solid background based on the text color can be a great alternative.</p>
                    </div>
                </div>
                <div class="tweet-info-counts">
                    <AccordionHeader class="comments" targetId="1">
                        <svg class="feather feather-message-circle sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                        <div class="comment-count">33</div>
                    </AccordionHeader>
                    <div class="likes">
                        <svg class="feather feather-heart sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                        <div class="likes-count">
                            2.6k
                        </div>
                    </div>
                    <div class="edit-action-button">
                        <button class="btn btn-sm edit-action">Edit</button>
                    </div>
                    <div class="delete-action-button">
                        <button class=" btn btn-sm delete-action">Delete</button>
                    </div>
                </div>
                <AccordionBody accordionId="1">
                    <div class="comment-replies mt-4 bg-light p-3 ml-3 rounded">
                        <div class="tweet-header">
                            <div class="tweet-header-info-comment">
                                <span class="comment-detail">Steve Schoger<span>. Jun 27</span></span>
                                <p class="comment-text">🔥 If you're tired of using outline styles for secondary buttons, a soft solid background based on the text color can be a great alternative.</p>
                            </div>
                        </div>
                    </div>
                    <div class="comment-replies mt-4 bg-light p-3 ml-3 rounded" accordionId="1">
                        <div class="tweet-header">
                            <div class="tweet-header-info-comment">
                                <span class="comment-detail">Steve Schoger<span>. Jun 27</span></span>
                                <p class="comment-text">🔥 If you're tired of using outline styles for secondary buttons, a soft solid background based on the text color can be a great alternative.</p>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Comment here..." aria-label="Recipient's username" aria-describedby="button-addon2" />
                    <button class="btn btn-outline-secondary" type="button" id="button-addon2">Reply</button>
                </div>
                </AccordionBody>
            </AccordionItem>
        </Accordion>
    )
}
export default Tweet;