import React, {Component} from 'react';
import "./Home.css"
import Logo from "../../Shared/icons8-twitter-144.png";
import Tweet from '../TweetTemplate/Tweet';

class Home extends Component{
    render(){
        return(
            <div class="home-container">
            <header>
                <img src={Logo}/>
                <h1 class="username-home"> Abhishek kumar </h1>
            </header>
            <div class="main">
                <form id="form">
                    <p>Tweet</p>
                    <textarea id="tweet" class="form-control" rows="3"></textarea>
                    <button type="submit" class="btn btn-primary mt-3">Tweet</button>
                </form>
                <div id="tweets">
                    <h5>My Tweets</h5>
                    <div id="list-tweets">
                        <Tweet/>
                        <Tweet/>
                    </div>
                </div>
            </div>
        </div>
        )
    }
}
export default Home