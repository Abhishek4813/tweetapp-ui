import React from 'react';
import { useState } from 'react';
import { Alert } from 'reactstrap';
import  { useNavigate } from 'react-router-dom'
import "./Login.css";

function Login() {
    const [inputs, setInputs] = useState({});
    const [show, setShow] = useState(false);
    const [errorMsg, setError] = useState('');
    const redirect = useNavigate();
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({ ...values, [name]: value }))
        if (event.target.value == "") {
            event.target.classList.add("is-invalid");
        }
        else {
            event.target.classList.remove("is-invalid");

        } 

    }
    const onDismiss = () => setShow(false);
    const handleSubmit = (event) => {
        event.preventDefault();
        fetch("http://localhost:8081/api/v1.0/tweets/login?username="+inputs.username+"&password="+inputs.password, {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'same-origin'
            }
        }).then(response => response.json()).then(data => {
            if (data && data.errorMsg) {
                setError("Invalid Credential");
                setShow(true);
                return;
            }
            localStorage.setItem("username",inputs.username);
            localStorage.setItem("Token",data.token);
            document.getElementById("loginbtn").innerHTML="Logout";
            redirect('/tweetapp/home');
        }).catch(error => {
            console.log(error);
        })
    }
    return (
        <div class="container">
            <Alert color="danger" isOpen={show} toggle={onDismiss}>
                <strong>Error ! </strong> {errorMsg}
            </Alert>
            <div id="loginForm" class="card mr-auto ml-auto mt-4 p-4">
                <h2 class="text-secondary text-center">Login</h2>
                <form class="p-4 form" onSubmit={handleSubmit}>
                    <div class="form-group">
                        <label for="username"> Username </label>
                        <input type="text" name="username" class="form-control" value={inputs.username || ""} onChange={handleChange} required />
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="password" value={inputs.password || ""} onChange={handleChange} required />
                    </div>
                    <div class="form-group">
                        <a href="/tweetapp/change/password">Change Password</a>
                    </div>
                    <br />
                    <input type="submit" value="Login" class="btn btn-primary btn-block" />
                </form>
                <br />
                <p class="text-right">Don't have an account? <a href="/tweetapp/register">Register here.</a></p>
            </div>
        </div>
    )
}
export default Login;