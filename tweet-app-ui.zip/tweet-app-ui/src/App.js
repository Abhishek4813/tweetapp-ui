import './App.css';
import { Component } from 'react';
import {Routes, Route, BrowserRouter as Router } from 'react-router-dom';
import Navigationbar from './Components/Navigation/Navigationbar';
import Home from './Components/Home/Home';
import Users from './Components/Users/Users';
import Tweets from './Components/Tweets/Tweets';
import Register from './Components/Register/Register';
import Login from './Components/Login/Login';
import Reset from './Components/PasswordReset/Reset';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Navigationbar />
        <Router>
          <Routes>
            <Route path={"/"} element={<Tweets />} />
            <Route path="/tweetapp/home" element={<Home />} />
            <Route path="/tweetapp/register" element={<Register />} />
            <Route path="/tweetapp/users" element={<Users />} />
            <Route path="/tweetapp/tweets" element={<Tweets />} />
            <Route path="/tweetapp/login" element={<Login />} />
            <Route path="/tweetapp/change/password" element={<Reset />} />
          </Routes>
        </Router>
      </div>
    );
  }
}

export default App;
